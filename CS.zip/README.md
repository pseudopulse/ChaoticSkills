# Chaotic Skills
Adds a bunch of alternate skills!

## Captain
Beacon: Design (Misc) - Emits waves that cripple and knockback ALL characters.
Beacon: Void (Misc) - Vo??id Fo??g slowly damages enemies within the radius.
Offensive Microbots (Passive) - Gain 3 combatant microbots that fire slowing lasers at nearby enemies for 160% damage, and one alongside you for 360% damage
Gaze of the Void (Primary) - Unleash a barrage of void missiles for 70% damage each. Requires time to spin up and spin down. 50% slow on self when active

## Commando
SFG-900 (Primary) - Stunning. Launch a slow-moving energy ball for 700% damage.

## Engineer
TR-80 Sniper Turret (Special) - Place a turret that inherits all of your items. Fires a periodic burst of 3 piercing bolts for 700% per shot that slow. Can place up to 1.

PM-30 Support Turret (Special) - Place a turret that inherits all of your items. Heals it's owner and provides them with 8 seconds of invulnerability and guaranteed critical hits after enough healing. Can place up to 1

Overdrive Boost (Utility) - Agile. Stunning. Launch into the air and boost forward after a short delay. Deal 100%-2500% damage depending on fall speed. Immunity to fall damage while boosting.

Thermal Blast (Primary) - Agile. Ignite. Fire dual flamethrowers for 600% damage.

## Mercenary
Fluoresence (Secondary) - Agile. Tether enemies, dragging them towards you and repeatedly strike them for 15% damage. 50% slow on self when active.
